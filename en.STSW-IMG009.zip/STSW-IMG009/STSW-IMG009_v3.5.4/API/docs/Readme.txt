VL53L1X ULD user manual UM2510 is avaliable on below link:
https://www.st.com/resource/en/user_manual/um2510-a-guide-to-using-the-vl53l1x-ultra-lite-driver-stmicroelectronics.pdf